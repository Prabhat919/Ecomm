﻿namespace EcomStore.ECommerceService.Business_Layer.DTO
{
    public class OrderProductDTO
    {
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        // Add other properties as needed
    }
}
