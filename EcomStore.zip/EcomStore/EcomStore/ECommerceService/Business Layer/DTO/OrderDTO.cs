﻿namespace EcomStore.ECommerceService.Business_Layer.DTO
{
    public class OrderDTO
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public decimal TotalAmount { get; set; }
        // Add other properties as needed
    }
}
