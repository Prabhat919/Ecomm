﻿namespace EcomStore.ECommerceService.Business_Layer.DTO
{
    public class ProductDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        // Add other properties as needed
    }
}
