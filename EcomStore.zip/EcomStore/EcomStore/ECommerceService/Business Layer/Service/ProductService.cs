﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Data_Access_Layer.Models;
using EcomStore.ECommerceService.Data_Access_Layer.Repository;
using OpenQA.Selenium;

namespace EcomStore.ECommerceService.Business_Layer.Service
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;

        public ProductService(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }

        public IEnumerable<ProductDTO> GetAllProducts()
        {
            var products = _productRepository.GetAll();
            return MapToDTOList(products);
        }

        public ProductDTO GetProductById(int productId)
        {
            var product = _productRepository.GetById(productId);
            return MapToDTO(product);
        }

        public ProductDTO CreateProduct(ProductDTO productDTO)
        {
            var product = MapToEntity(productDTO);
            _productRepository.Create(product);
            _productRepository.SaveChanges();
            return new ProductDTO();

        }

        public void UpdateProduct(int id,ProductDTO productDTO)
        {
            var existingProduct = _productRepository.GetById(productDTO.Id);
            if (existingProduct == null)
            {
                // Handle error or throw exception
                return;
            }

            // Update the existing product entity with the new values
            existingProduct.ProductName = productDTO.Name;
            existingProduct.Price = productDTO.Price;

            _productRepository.Update(existingProduct);
            _productRepository.SaveChanges();
        }

        public void DeleteProduct(int productId)
        {
            var product = _productRepository.GetById(productId);
            if (product != null)
            {
                _productRepository.Delete(product);
                _productRepository.SaveChanges();
            }
        }

        private ProductDTO MapToDTO(Product product)
        {
            if (product != null)
            {
                return new ProductDTO
                {
                    Id = product.Id,
                    Name = product.ProductName,
                    Price = product.Price
                };
            }

            // Handle error or throw exception
            return null;
        }

        private IEnumerable<ProductDTO> MapToDTOList(IEnumerable<Product> products)
        {
            if (products != null)
            {
                return products.Select(p => new ProductDTO
                {
                    Id = p.Id,
                    Name = p.ProductName,
                    Price = p.Price
                });
            }

            // Handle error or throw exception
            return null;
        }

        private Product MapToEntity(ProductDTO productDTO)
        {
            if (productDTO != null)
            {
                return new Product
                {
                    Id = productDTO.Id,
                    ProductName = productDTO.Name,
                    Price = productDTO.Price
                };
            }

            // Handle error or throw exception
            return null;
        }
    }
}