﻿using EcomStore.ECommerceService.Business_Layer.DTO;

namespace EcomStore.ECommerceService.Business_Layer.Service
{
    public interface IOrderService
    {
        IEnumerable<OrderDTO> GetAllOrders();
        OrderDTO GetOrderById(int id);
        OrderDTO CreateOrder(OrderDTO orderDTO);
        void UpdateOrder(int id, OrderDTO orderDTO);
        void DeleteOrder(int id);
    }
}
