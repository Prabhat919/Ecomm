﻿using EcomStore.ECommerceService.Business_Layer.DTO;

namespace EcomStore.ECommerceService.Business_Layer.Service
{
    public interface IOrderProductService
    {
        IEnumerable<OrderProductDTO> GetAllOrderProducts();
        OrderProductDTO GetOrderProductById(int orderId, int productId);
        OrderProductDTO CreateOrderProduct(OrderProductDTO orderProductDTO);
        void UpdateOrderProduct(OrderProductDTO orderProductDTO);
        void DeleteOrderProduct(int orderId, int productId);
    }
}
