﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Business_Layer.Service;
using EcomStore.ECommerceService.Data_Access_Layer.Models;
using EcomStore.ECommerceService.Data_Access_Layer.Repository;

namespace EcomStore.ECommerceService.Business_Layer.Service
{
    public interface IPaymentService
    {
        IEnumerable<PaymentDTO> GetAllPayments();
        PaymentDTO GetPaymentById(int id);
        PaymentDTO CreatePayment(PaymentDTO paymentDTO);
        void UpdatePayment(PaymentDTO paymentDTO);
        void DeletePayment(int id);
    }
}

