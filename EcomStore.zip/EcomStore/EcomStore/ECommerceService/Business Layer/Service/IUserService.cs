﻿using EcomStore.ECommerceService.Business_Layer.DTO;

namespace EcomStore.ECommerceService.Business_Layer.Service
{
    public interface IUserService
    {
        IEnumerable<UserDTO> GetAllUsers();
        UserDTO GetUserById(int id);
        UserDTO CreateUser(UserDTO userDTO);
        void UpdateUser(int id, UserDTO userDto);
        void DeleteUser(int id);
    }
}
