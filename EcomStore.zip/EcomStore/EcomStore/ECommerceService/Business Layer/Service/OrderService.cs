﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Data_Access_Layer.Models;
using EcomStore.ECommerceService.Data_Access_Layer.Repository;

namespace EcomStore.ECommerceService.Business_Layer.Service
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;

        public OrderService(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        public IEnumerable<OrderDTO> GetAllOrders()
        {
            try
            {
                var orders = _orderRepository.GetAllOrders();
                return MapOrdersToDTOs(orders);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                // You can throw a custom exception or return a default value/error message if needed
                throw new Exception("Failed to retrieve orders.", ex);
            }
        }

        public OrderDTO GetOrderById(int id)
        {
            try
            {
                var order = _orderRepository.GetOrderById(id);
                if (order == null)
                {
                    // Handle the case when the order is not found
                    throw new ArgumentException($"Order with Id {id} not found.");
                }

                return MapOrderToDTO(order);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception($"Failed to retrieve order with Id {id}.", ex);
            }
        }

        public OrderDTO CreateOrder(OrderDTO orderDTO)
        {
            try
            {
                var order = MapDTOToOrder(orderDTO);
                _orderRepository.AddOrder(order);
                _orderRepository.SaveChanges();
                orderDTO.Id = order.Id; // Update the DTO with the generated Id
                return orderDTO; // Return the created orderDTO
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                throw new Exception("Failed to create the order.", ex);
            }
        }

        public void UpdateOrder(int id, OrderDTO orderDTO)
        {
            try
            {
                var order = MapDTOToOrder(orderDTO);
                _orderRepository.UpdateOrder(order);
                _orderRepository.SaveChanges();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception($"Failed to update order with Id {orderDTO.Id}.", ex);
            }
        }

        public void DeleteOrder(int id)
        {
            try
            {
                var order = _orderRepository.GetOrderById(id);
                if (order == null)
                {
                    // Handle the case when the order is not found
                    throw new ArgumentException($"Order with Id {id} not found.");
                }

                _orderRepository.DeleteOrder(order);
                _orderRepository.SaveChanges();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception($"Failed to delete order with Id {id}.", ex);
            }
        }

        private OrderDTO MapOrderToDTO(Order order)
        {
            return new OrderDTO
            {
                Id = order.Id,
                UserId = order.UserId,
                TotalAmount = CalculateTotalAmount(order) // Calculate the total amount based on the order's products
                // Map other properties as needed
            };
        }

        private IEnumerable<OrderDTO> MapOrdersToDTOs(IEnumerable<Order> orders)
        {
            return orders.Select(order => MapOrderToDTO(order));
        }

        private Order MapDTOToOrder(OrderDTO orderDTO)
        {
            return new Order
            {
                Id = orderDTO.Id,
                UserId = orderDTO.UserId,
                // Map other properties as needed
            };
        }

        private decimal CalculateTotalAmount(Order order)
        {
            // Perform the calculation based on the order's products
            decimal totalAmount = 0;
            foreach (var orderProduct in order.OrderProducts)
            {
                // Assuming each OrderProduct has a Product reference with a Price property
                totalAmount += orderProduct.Product.Price;
            }
            return totalAmount;
        }
    }
}

