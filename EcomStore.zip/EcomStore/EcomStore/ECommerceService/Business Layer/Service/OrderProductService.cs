﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Data_Access_Layer.Models;
using EcomStore.ECommerceService.Data_Access_Layer.Repository;

namespace EcomStore.ECommerceService.Business_Layer.Service
{
    public class OrderProductService : IOrderProductService
    {
        private readonly IOrderProductRepository _orderProductRepository;

        public OrderProductService(IOrderProductRepository orderProductRepository)
        {
            _orderProductRepository = orderProductRepository;
        }

        public IEnumerable<OrderProductDTO> GetAllOrderProducts()
        {
            try
            {
                var orderProducts = _orderProductRepository.GetAllOrderProducts();
                return MapOrderProductsToDTOs(orderProducts);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception("Failed to retrieve order products.", ex);
            }
        }

        public OrderProductDTO GetOrderProductById(int orderId, int productId)
        {
            try
            {
                var orderProduct = _orderProductRepository.GetOrderProductById(orderId, productId);
                if (orderProduct == null)
                {
                    // Handle the case when the order product is not found
                    throw new ArgumentException($"Order product with OrderId {orderId} and ProductId {productId} not found.");
                }

                return MapOrderProductToDTO(orderProduct);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception($"Failed to retrieve order product with OrderId {orderId} and ProductId {productId}.", ex);
            }
        }

        public OrderProductDTO CreateOrderProduct(OrderProductDTO orderProductDTO)
        {
            try
            {
                var orderProduct = MapDTOToOrderProduct(orderProductDTO);
                _orderProductRepository.AddOrderProduct(orderProduct);
                _orderProductRepository.SaveChanges();
                return orderProductDTO; // Return the created orderProductDTO
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                throw new Exception("Failed to create the order product.", ex);
            }
        }

        public void UpdateOrderProduct(OrderProductDTO orderProductDTO)
        {
            try
            {
                var orderProduct = MapDTOToOrderProduct(orderProductDTO);
                _orderProductRepository.UpdateOrderProduct(orderProduct);
                _orderProductRepository.SaveChanges();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception($"Failed to update order product with OrderId {orderProductDTO.OrderId} and ProductId {orderProductDTO.ProductId}.", ex);
            }
        }

        public void DeleteOrderProduct(int orderId, int productId)
        {
            try
            {
                var orderProduct = _orderProductRepository.GetOrderProductById(orderId, productId);
                if (orderProduct == null)
                {
                    // Handle the case when the order product is not found
                    throw new ArgumentException($"Order product with OrderId {orderId} and ProductId {productId} not found.");
                }

                _orderProductRepository.DeleteOrderProduct(orderProduct);
                _orderProductRepository.SaveChanges();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception($"Failed to delete order product with OrderId {orderId} and ProductId {productId}.", ex);
            }
        }

        private OrderProductDTO MapOrderProductToDTO(OrderProduct orderProduct)
        {
            return new OrderProductDTO
            {
                OrderId = orderProduct.OrderId,
                ProductId = orderProduct.ProductId,
                Quantity = orderProduct.Quantity
                // Map other properties as needed
            };
        }

        private IEnumerable<OrderProductDTO> MapOrderProductsToDTOs(IEnumerable<OrderProduct> orderProducts)
        {
            var orderProductDTOs = new List<OrderProductDTO>();
            foreach (var orderProduct in orderProducts)
            {
                orderProductDTOs.Add(MapOrderProductToDTO(orderProduct));
            }
            return orderProductDTOs;
        }

        private OrderProduct MapDTOToOrderProduct(OrderProductDTO orderProductDTO)
        {
            return new OrderProduct
            {
                OrderId = orderProductDTO.OrderId,
                ProductId = orderProductDTO.ProductId,
                Quantity = orderProductDTO.Quantity
                // Map other properties as needed
            };
        }
    }
}
