﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Data_Access_Layer.Models;
using EcomStore.ECommerceService.Data_Access_Layer.Repository;

namespace EcomStore.ECommerceService.Business_Layer.Service
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public IEnumerable<UserDTO> GetAllUsers()
        {
            try
            {
                var users = _userRepository.GetAllUsers();
                return MapUsersToDTOs(users);
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                // You can throw a custom exception or return a default value/error message
                throw new Exception("Failed to retrieve users.", ex);
            }
        }

        public UserDTO GetUserById(int id)
        {
            try
            {
                var user = _userRepository.GetUserById(id);
                return MapUserToDTO(user);
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                // You can throw a custom exception or return a default value/error message
                throw new Exception($"Failed to retrieve user with ID {id}.", ex);
            }
        }

        public UserDTO CreateUser(UserDTO userDTO)
        {
            try
            {
                var user = MapDTOToUser(userDTO);
                _userRepository.AddUser(user);
                _userRepository.SaveChanges();
                userDTO.Id = user.Id; // Update the DTO with the generated Id
                return userDTO; // Return the created userDTO
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                throw new Exception("Failed to add the user.", ex);
            }
        }

        public void UpdateUser(int id, UserDTO userDTO)
        {
            try
            {
                var user = MapDTOToUser(userDTO);
                _userRepository.UpdateUser(user);
                _userRepository.SaveChanges();
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                throw new Exception($"Failed to update user with ID {userDTO.Id}.", ex);
            }
        }

        public void DeleteUser(int id)
        {
            try
            {
                var user = _userRepository.GetUserById(id);
                if (user != null)
                {
                    _userRepository.DeleteUser(user);
                    _userRepository.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                throw new Exception($"Failed to delete user with ID {id}.", ex);
            }
        }

        private UserDTO MapUserToDTO(User user)
        {
            return new UserDTO
            {
                Id = user.Id,
                Name = user.Name,
                UserName = user.UserName,
                Email = user.Email,
                IsAdmin = user.IsAdmin
                // Map other properties as needed
            };
        }

        private IEnumerable<UserDTO> MapUsersToDTOs(IEnumerable<User> users)
        {
            var userDTOs = new List<UserDTO>();
            foreach (var user in users)
            {
                userDTOs.Add(MapUserToDTO(user));
            }
            return userDTOs;
        }

        private User MapDTOToUser(UserDTO userDTO)
        {
            return new User
            {
                Id = userDTO.Id,
                Name = userDTO.Name,
                UserName = userDTO.UserName,
                Email = userDTO.Email,
                IsAdmin = userDTO.IsAdmin
                // Map other properties as needed
            };
        }
    }
}
