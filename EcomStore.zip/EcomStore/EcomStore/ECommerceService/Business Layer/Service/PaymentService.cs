﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Data_Access_Layer.Models;
using EcomStore.ECommerceService.Data_Access_Layer.Repository;

namespace EcomStore.ECommerceService.Business_Layer.Service
{
    public class PaymentService : IPaymentService
    {
        private readonly IPaymentRepository _paymentRepository;

        public PaymentService(IPaymentRepository paymentRepository)
        {
            _paymentRepository = paymentRepository;
        }

        public IEnumerable<PaymentDTO> GetAllPayments()
        {
            try
            {
                var payments = _paymentRepository.GetAllPayments();
                return MapPaymentsToDTOs(payments);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception("Failed to retrieve payments.", ex);
            }
        }

        public PaymentDTO GetPaymentById(int id)
        {
            try
            {
                var payment = _paymentRepository.GetPaymentById(id);
                if (payment == null)
                {
                    // Handle the case when the payment is not found
                    throw new ArgumentException($"Payment with Id {id} not found.");
                }

                return MapPaymentToDTO(payment);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception($"Failed to retrieve payment with Id {id}.", ex);
            }
        }

        public PaymentDTO CreatePayment(PaymentDTO paymentDTO)
        {
            try
            {
                var payment = MapDTOToPayment(paymentDTO);
                _paymentRepository.AddPayment(payment);
                _paymentRepository.SaveChanges();
                paymentDTO.Id = payment.Id; // Update the DTO with the generated Id
                return paymentDTO; // Return the created paymentDTO
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                throw new Exception("Failed to create the payment.", ex);
            }
        }

        public void UpdatePayment(PaymentDTO paymentDTO)
        {
            try
            {
                var payment = MapDTOToPayment(paymentDTO);
                _paymentRepository.UpdatePayment(payment);
                _paymentRepository.SaveChanges();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception($"Failed to update payment with Id {paymentDTO.Id}.", ex);
            }
        }

        public void DeletePayment(int id)
        {
            try
            {
                var payment = _paymentRepository.GetPaymentById(id);
                if (payment == null)
                {
                    // Handle the case when the payment is not found
                    throw new ArgumentException($"Payment with Id {id} not found.");
                }

                _paymentRepository.DeletePayment(payment);
                _paymentRepository.SaveChanges();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                throw new Exception($"Failed to delete payment with Id {id}.", ex);
            }
        }

        private PaymentDTO MapPaymentToDTO(Payment payment)
        {
            return new PaymentDTO
            {
                Id = payment.Id,
              
                Amount = payment.Amount,
                // Map other properties as needed
            };
        }

        private IEnumerable<PaymentDTO> MapPaymentsToDTOs(IEnumerable<Payment> payments)
        {
            return payments.Select(payment => MapPaymentToDTO(payment));
        }

        private Payment MapDTOToPayment(PaymentDTO paymentDTO)
        {
            return new Payment
            {
                Id = paymentDTO.Id,
                Amount = paymentDTO.Amount,
                // Map other properties as needed
            };
        }
    }
}
