﻿using EcomStore.ECommerceService.Business_Layer.DTO;

namespace EcomStore.ECommerceService.Business_Layer.Service
{
    public interface IProductService
    {
        ProductDTO GetProductById(int id);
        IEnumerable<ProductDTO> GetAllProducts();
        ProductDTO CreateProduct(ProductDTO productDto);
        void UpdateProduct(int id, ProductDTO productDto);
        void DeleteProduct(int id);
    }
}
