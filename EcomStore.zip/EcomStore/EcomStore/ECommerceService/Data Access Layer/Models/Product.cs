﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace EcomStore.ECommerceService.Data_Access_Layer.Models
{
    public class Product
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        [Display(Name = "Product Name")]
        public string ProductName { get; set; }

        [Required]
        public decimal Price { get; set; }

        // Navigation properties
        public ICollection<Order> Orders { get; set; }
        public ICollection<OrderProduct> OrderProducts { get; set; }
    }
}


