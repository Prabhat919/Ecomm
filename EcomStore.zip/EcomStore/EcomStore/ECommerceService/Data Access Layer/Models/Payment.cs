﻿using System.ComponentModel.DataAnnotations;

namespace EcomStore.ECommerceService.Data_Access_Layer.Models
{
    public class Payment
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int OrderId { get; set; }

        [Required]
        public decimal Amount { get; set; }

        // Navigation property
        public Order Order { get; set; }
    }
}
