﻿using System.ComponentModel.DataAnnotations;

namespace EcomStore.ECommerceService.Data_Access_Layer.Models
{
    public class Order
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public int UserId { get; set; }

        public DateTime OrderDate { get; set; }

        // Navigation properties
        public User User { get; set; }
        public ICollection<Product> Products { get; set; }
        public Payment Payment { get; set; }
        public ICollection<OrderProduct> OrderProducts { get; set; }
    }
}
