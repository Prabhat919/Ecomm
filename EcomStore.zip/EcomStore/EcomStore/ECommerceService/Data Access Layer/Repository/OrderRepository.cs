﻿using EcomStore.ECommerceService.Data_Access_Layer.Data;
using EcomStore.ECommerceService.Data_Access_Layer.Models;

namespace EcomStore.ECommerceService.Data_Access_Layer.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly EcomStoreDbContext _dbContext;

        public OrderRepository(EcomStoreDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<Order> GetAllOrders()
        {
            return _dbContext.Orders;
        }

        public Order GetOrderById(int id)
        {
            return _dbContext.Orders.Find(id);
        }

        public void AddOrder(Order order)
        {
            _dbContext.Orders.Add(order);
        }

        public void UpdateOrder(Order order)
        {
            _dbContext.Orders.Update(order);
        }

        public void DeleteOrder(Order order)
        {
            _dbContext.Orders.Remove(order);
        }

        public void SaveChanges()
        {
            _dbContext.SaveChanges();
        }
    }
}
