﻿using EcomStore.ECommerceService.Data_Access_Layer.Models;

namespace EcomStore.ECommerceService.Data_Access_Layer.Repository
{
    public interface IOrderProductRepository
    {
        IEnumerable<OrderProduct> GetAllOrderProducts();
        OrderProduct GetOrderProductById(int orderId, int productId);
        void AddOrderProduct(OrderProduct orderProduct);
        void UpdateOrderProduct(OrderProduct orderProduct);
        void DeleteOrderProduct(OrderProduct orderProduct);
        void SaveChanges();
    }
}
