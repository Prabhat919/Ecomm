﻿using EcomStore.ECommerceService.Data_Access_Layer.Models;

namespace EcomStore.ECommerceService.Data_Access_Layer.Repository
{
    public interface IPaymentRepository
    {
        IEnumerable<Payment> GetAllPayments();
        Payment GetPaymentById(int id);
        void AddPayment(Payment payment);
        void UpdatePayment(Payment payment);
        void DeletePayment(Payment payment);
        void SaveChanges();
    }

}
