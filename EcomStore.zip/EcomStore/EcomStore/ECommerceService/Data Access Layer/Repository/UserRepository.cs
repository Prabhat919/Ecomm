﻿using EcomStore.ECommerceService.Data_Access_Layer.Data;
using EcomStore.ECommerceService.Data_Access_Layer.Models;

namespace EcomStore.ECommerceService.Data_Access_Layer.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly EcomStoreDbContext _dbContext;

        public UserRepository(EcomStoreDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<User> GetAllUsers()
        {
            return _dbContext.Users;
        }

        public User GetUserById(int id)
        {
            return _dbContext.Users.Find(id);
        }

        public void AddUser(User user)
        {
            _dbContext.Users.Add(user);
        }

        public void UpdateUser(User user)
        {
            _dbContext.Users.Update(user);
        }

        public void DeleteUser(User user)
        {
            _dbContext.Users.Remove(user);
        }

        public void SaveChanges()
        {
            _dbContext.SaveChanges();
        }
    }
}
