﻿using EcomStore.ECommerceService.Data_Access_Layer.Models;

namespace EcomStore.ECommerceService.Data_Access_Layer.Repository
{
    public interface IProductRepository
    {
        Product GetById(int productId);
        IEnumerable<Product> GetAll();
        void Create(Product product);
        void Update(Product product);
        void Delete(Product product);
        void SaveChanges();
    }
}
