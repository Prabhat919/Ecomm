﻿using EcomStore.ECommerceService.Data_Access_Layer.Models;

namespace EcomStore.ECommerceService.Data_Access_Layer.Repository
{
    public interface IUserRepository
    {
        IEnumerable<User> GetAllUsers();
        User GetUserById(int id);
        void AddUser(User user);
        void UpdateUser(User user);
        void DeleteUser(User user);
        void SaveChanges();
    }
}
