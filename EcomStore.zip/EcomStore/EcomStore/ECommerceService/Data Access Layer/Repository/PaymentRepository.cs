﻿using EcomStore.ECommerceService.Data_Access_Layer.Data;
using EcomStore.ECommerceService.Data_Access_Layer.Models;

namespace EcomStore.ECommerceService.Data_Access_Layer.Repository
{
    public class PaymentRepository : IPaymentRepository
    {
        private readonly EcomStoreDbContext _dbContext;

        public PaymentRepository(EcomStoreDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<Payment> GetAllPayments()
        {
            return _dbContext.Payments;
        }

        public Payment GetPaymentById(int id)
        {
            return _dbContext.Payments.Find(id);
        }

        public void AddPayment(Payment payment)
        {
            _dbContext.Payments.Add(payment);
        }

        public void UpdatePayment(Payment payment)
        {
            _dbContext.Payments.Update(payment);
        }

        public void DeletePayment(Payment payment)
        {
            _dbContext.Payments.Remove(payment);
        }

        public void SaveChanges()
        {
            _dbContext.SaveChanges();
        }
    }
}
