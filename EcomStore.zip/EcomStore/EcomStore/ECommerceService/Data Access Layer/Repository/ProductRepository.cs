﻿using EcomStore.ECommerceService.Data_Access_Layer.Data;
using EcomStore.ECommerceService.Data_Access_Layer.Models;

namespace EcomStore.ECommerceService.Data_Access_Layer.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly EcomStoreDbContext _dbContext;

        public ProductRepository(EcomStoreDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public Product GetById(int productId)
        {
            return _dbContext.Products.Find(productId);
        }

        public IEnumerable<Product> GetAll()
        {
            return _dbContext.Products.ToList();
        }

        public void Create(Product product)
        {
            _dbContext.Products.Add(product);
        }

        public void Update(Product product)
        {
            _dbContext.Products.Update(product);
        }

        public void Delete(Product product)
        {
            _dbContext.Products.Remove(product);
        }

        public void SaveChanges()
        {
            _dbContext.SaveChanges();
        }
    }
}
