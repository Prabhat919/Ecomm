﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Business_Layer.Service;
using Microsoft.AspNetCore.Mvc;

namespace EcomStore.Controllers
{
    [ApiController]
    [Route("api/orderproducts")]
    public class OrderProductController : ControllerBase
    {
        private readonly IOrderProductService _orderProductService;

        public OrderProductController(IOrderProductService orderProductService)
        {
            _orderProductService = orderProductService;
        }

        [HttpGet]
        public IActionResult GetAllOrderProducts()
        {
            try
            {
                var orderProducts = _orderProductService.GetAllOrderProducts();
                return Ok(orderProducts);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                return StatusCode(500, "An error occurred while retrieving the order products.");
            }
        }

        [HttpGet("{orderId}/{productId}")]
        public IActionResult GetOrderProductById(int orderId, int productId)
        {
            try
            {
                var orderProduct = _orderProductService.GetOrderProductById(orderId, productId);
                if (orderProduct == null)
                {
                    return NotFound();
                }

                return Ok(orderProduct);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                return StatusCode(500, "An error occurred while retrieving the order product.");
            }
        }

        [HttpPost]
        public IActionResult CreateOrderProduct(OrderProductDTO orderProductDTO)
        {
            try
            {
                var createdOrderProduct = _orderProductService.CreateOrderProduct(orderProductDTO);
                return CreatedAtAction(nameof(GetOrderProductById), new { orderId = createdOrderProduct.OrderId, productId = createdOrderProduct.ProductId }, createdOrderProduct);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                return StatusCode(500, "An error occurred while creating the order product.");
            }
        }

        [HttpPut]
        public IActionResult UpdateOrderProduct(OrderProductDTO orderProductDTO)
        {
            try
            {
                _orderProductService.UpdateOrderProduct(orderProductDTO);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                return StatusCode(500, "An error occurred while updating the order product.");
            }
        }

        [HttpDelete("{orderId}/{productId}")]
        public IActionResult DeleteOrderProduct(int orderId, int productId)
        {
            try
            {
                _orderProductService.DeleteOrderProduct(orderId, productId);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                return StatusCode(500, "An error occurred while deleting the order product.");
            }
        }
    }
}
