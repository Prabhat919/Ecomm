﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Business_Layer.Service;
using Microsoft.AspNetCore.Mvc;

namespace EcomStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public IActionResult GetAllUsers()
        {
            try
            {
                var users = _userService.GetAllUsers();
                return Ok(users);
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                return StatusCode(500, "Failed to retrieve users.");
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetUserById(int id)
        {
            try
            {
                var user = _userService.GetUserById(id);
                if (user == null)
                {
                    return NotFound();
                }
                return Ok(user);
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                return StatusCode(500, $"Failed to retrieve user with ID {id}.");
            }
        }

        [HttpPost]
        public IActionResult CreateUser([FromBody] UserDTO userDTO)
        {
            try
            {
                var createdUser = _userService.CreateUser(userDTO);
                return CreatedAtAction(nameof(GetUserById), new { id = createdUser.Id }, createdUser);
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                return StatusCode(500, "Failed to create the user.");
            }
        }

        [HttpPut("{id}")]
        public IActionResult UpdateUser(int id, [FromBody] UserDTO userDTO)
        {
            try
            {
                _userService.UpdateUser(id, userDTO);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                return StatusCode(500, $"Failed to update user with ID {id}.");
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteUser(int id)
        {
            try
            {
                _userService.DeleteUser(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Handle the exception or log the error
                return StatusCode(500, $"Failed to delete user with ID {id}.");
            }
        }
    }
}
