﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Business_Layer.Service;
using Microsoft.AspNetCore.Mvc;

namespace EcomStore.Controllers
{
    [ApiController]
    [Route("api/payments")]
    public class PaymentController : ControllerBase
    {
        private readonly IPaymentService _paymentService;

        public PaymentController(IPaymentService paymentService)
        {
            _paymentService = paymentService;
        }

        [HttpGet]
        public IActionResult GetAllPayments()
        {
            try
            {
                var payments = _paymentService.GetAllPayments();
                return Ok(payments);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                return StatusCode(500, "Failed to retrieve payments.");
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetPaymentById(int id)
        {
            try
            {
                var payment = _paymentService.GetPaymentById(id);
                if (payment == null)
                {
                    return NotFound($"Payment with Id {id} not found.");
                }

                return Ok(payment);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                return StatusCode(500, $"Failed to retrieve payment with Id {id}.");
            }
        }

        [HttpPost]
        public IActionResult CreatePayment(PaymentDTO paymentDTO)
        {
            try
            {
                var createdPayment = _paymentService.CreatePayment(paymentDTO);
                return CreatedAtAction(nameof(GetPaymentById), new { id = createdPayment.Id }, createdPayment);
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                return StatusCode(500, "Failed to create the payment.");
            }
        }

        [HttpPut("{id}")]
        public IActionResult UpdatePayment(int id, PaymentDTO paymentDTO)
        {
            try
            {
                var existingPayment = _paymentService.GetPaymentById(id);
                if (existingPayment == null)
                {
                    return NotFound($"Payment with Id {id} not found.");
                }

                paymentDTO.Id = id; // Ensure the DTO has the correct ID
                _paymentService.UpdatePayment(paymentDTO);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                return StatusCode(500, $"Failed to update payment with Id {id}.");
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePayment(int id)
        {
            try
            {
                var existingPayment = _paymentService.GetPaymentById(id);
                if (existingPayment == null)
                {
                    return NotFound($"Payment with Id {id} not found.");
                }

                _paymentService.DeletePayment(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Handle and log the exception
                return StatusCode(500, $"Failed to delete payment with Id {id}.");
            }
        }
    }
}
