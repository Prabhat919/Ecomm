﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Business_Layer.Service;
using Microsoft.AspNetCore.Mvc;

namespace EcomStore.Controllers
{
    [Route("api/products")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<ProductDTO>> GetAllProducts()
        {
            try
            {
                var products = _productService.GetAllProducts();
                return Ok(products);
            }
            catch (Exception ex)
            {
                // Handle exception and return appropriate response
                return StatusCode(500, ex.Message);
            }
        }

        [HttpGet("{id}")]
        public ActionResult<ProductDTO> GetProductById(int id)
        {
            try
            {
                var product = _productService.GetProductById(id);

                if (product == null)
                    return NotFound();

                return Ok(product);
            }
            catch (Exception ex)
            {
                // Handle exception and return appropriate response
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPost]
        public ActionResult<ProductDTO> CreateProduct(ProductDTO productDto)
        {
            try
            {
                var createdProduct = _productService.CreateProduct(productDto);

                return CreatedAtAction(nameof(GetProductById), new { id = createdProduct.Id }, createdProduct);
            }
            catch (Exception ex)
            {
                // Handle exception and return appropriate response
                return StatusCode(500, ex.Message);
            }
        }

        [HttpPut("{id}")]
        public ActionResult UpdateProduct(int id, ProductDTO productDto)
        {
            try
            {
                var existingProduct = _productService.GetProductById(id);

                if (existingProduct == null)
                    return NotFound();

                _productService.UpdateProduct(id, productDto);

                return NoContent();
            }
            catch (Exception ex)
            {
                // Handle exception and return appropriate response
                return StatusCode(500, ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public ActionResult DeleteProduct(int id)
        {
            try
            {
                var existingProduct = _productService.GetProductById(id);

                if (existingProduct == null)
                    return NotFound();

                _productService.DeleteProduct(id);

                return NoContent();
            }
            catch (Exception ex)
            {
                // Handle exception and return appropriate response
                return StatusCode(500, ex.Message);
            }
        }
    }
}
