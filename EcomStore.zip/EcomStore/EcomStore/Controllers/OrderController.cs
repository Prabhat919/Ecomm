﻿using EcomStore.ECommerceService.Business_Layer.DTO;
using EcomStore.ECommerceService.Business_Layer.Service;
using Microsoft.AspNetCore.Mvc;

namespace EcomStore.Controllers
{
    [ApiController]
    [Route("api/orders")]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrderController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<OrderDTO>> GetAllOrders()
        {
            try
            {
                var orders = _orderService.GetAllOrders();
                return Ok(orders);
            }
            catch (Exception ex)
            {
                // Log the exception or return an appropriate error response
                return StatusCode(500, "Failed to retrieve orders.");
            }
        }

        [HttpGet("{id}")]
        public ActionResult<OrderDTO> GetOrderById(int id)
        {
            try
            {
                var order = _orderService.GetOrderById(id);
                if (order == null)
                {
                    return NotFound();
                }
                return Ok(order);
            }
            catch (Exception ex)
            {
                // Log the exception or return an appropriate error response
                return StatusCode(500, $"Failed to retrieve order with ID {id}.");
            }
        }

        [HttpPost]
        public ActionResult<OrderDTO> CreateOrder(OrderDTO orderDTO)
        {
            try
            {
                var createdOrder = _orderService.CreateOrder(orderDTO);
                return CreatedAtAction(nameof(GetOrderById), new { id = createdOrder.Id }, createdOrder);
            }
            catch (Exception ex)
            {
                // Log the exception or return an appropriate error response
                return StatusCode(500, "Failed to create the order.");
            }
        }

        [HttpPut("{id}")]
        public ActionResult UpdateOrder(int id, OrderDTO orderDTO)
        {
            try
            {
                _orderService.UpdateOrder(id, orderDTO);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Log the exception or return an appropriate error response
                return StatusCode(500, $"Failed to update order with ID {id}.");
            }
        }

        [HttpDelete("{id}")]
        public ActionResult DeleteOrder(int id)
        {
            try
            {
                _orderService.DeleteOrder(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Log the exception or return an appropriate error response
                return StatusCode(500, $"Failed to delete order with ID {id}.");
            }
        }
    }
}
    